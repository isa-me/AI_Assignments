=====Name and UTA ID======
Isaac Medrano 1001884307

=====Programming Language=====
Programming Language: C 
Compiler version: gcc (Ubuntu 11.4.0-1ubuntu1~22.04) 11.4.0
Omega Compatible: Yes

=====Code Structure=====
Everything is all in the find_route.c source file.
The code is structured into four parts:
1. The first part contains the libraries included, defined constants, and struct definitions.
2. Following 1, There will be function headers declarations. The function headers are divided into 4 parts
    - Debugging Functions: These are functions I created for the sake of debugging during the development process. They do not have an impact on the assignment and aren't used in the final deliverable.
    - Utility Functions: These are functions I created that are used by either the main() function, the Search Functions, or other Utility Functions. These functions help modularize and hide extra work that would have been done in main(), the Search Functions, or other Utility Functions. The comments in the header will indicate in which funcitons it is used. 
    - Search Functions: These are functions that implement the informed and uninformed graph search algorithm. These functions follow the structure provided in the pseudo-code. The names of these functions don't match the names defined in the pseudo-code. The comment line next to the headers will indicate which function in the pseudo-code it implements.
    - printRoute(): A function called in main() after the graphSearch function is done and returns the destination node. The way nodes are implemented in my program is that they keep track of who their parent is, but not their children. printRoute() will take the result node from graphSearch() and essentially traverse a link list backward, configuring the correct child node pointers along the way, then traverse back to the destination node from the root node and print the route.
3. The main function that reads the command line arguments, configures and launches the graphSearch algorithm. main() diverges into two distinct but similar paths depending on the number of arguments. If the argument counter is 4 that indicates the user wants to do an uninformed search while an argument counter of 5 indicates an informed search.
4. Part 4 contains all the function definitions for each function header declaration in part 1. The function definitions follow the same ordering that the function headers do. I will provide the line location for each function in this document
    Function Definition Line Location:
    =====Debugging Functions=====
    - [Line: 227] void printNodeID(char* nodeId)
    - [Line: 232] void nodeCpy(Node* destination, Node* source)
    - [Line: 243] void printNodeInfo(Node* node)
    - [Line: 262] void printNodeArray(int nodeNum, Node** nodeArray)
    - [Line: 287] void rawPrintNodeArray(int array_size, Node** nodeArray)
    - [Line: 307] char* greedyReturnLine(Problem* problem, char* target_city)
    - [Line: 338] float immediateCost(Node* node, Problem* problem)
    - [Line: 366] int howManyLines(Problem* problem)
    =====Utility Functions=====
    - [Line: 381] float searchHeuristic(char* city, Problem* problem)
    - [Line: 414] int howManyNodes(Node** nodeArray)
    - [Line: 426] void freeNodeArray(int array_size, Node** nodeArray)
    - [Line: 449] void incrementFringeSize(int* fringe_size, Node*** Fringe)
    - [Line: 464] Node* makeNode(char* childName, Problem* problem)
    - [Line: 508] Node* makeInitNode(Problem* problem)
    - [Line: 539] void insertSortFringe(Node** fringe, Problem* problem)
    - [Line: 582] bool searchClosed(Node** closed, int closed_size, Node* node )
    - [Line: 600] void push(int* fringe_size, Node* node, Node*** fringe)
    =====Search Functions=====
    - [Line: 615] Node* pop(Node*** fringe)
    - [Line: 628] Node** successorFn(Problem* problem, Node* node)
    - [Line: 707] float stepCost(Node* node, Node* s, Problem* problem)
    - [Line: 743] Node** initFringe(int* fringe_size, Problem* problem)
    - [Line: 760] Node* goalTest(Problem* problem, Node* node)
    - [Line: 767] Node** expand(Problem* problem, Node* node, Result* result)
    - [Line: 800] void insertAll(Node** successors, Node*** fringe, int* fringe_size, Problem* problem)
    - [Line: 815] Node* graphSearch(Problem* problem, Result* result)
    =====Prints the Optimal Route=====
    - [Line: 862] void printRoute(Node* node, Problem* problem)

    Note 1: The functions relevant to algorithm implementation are the Search Functions.
    Note 2: My chosen sorting algorithm is Insert Sort. It's a stable sorting algorithm so in the case that it sorts two nodes with the same key value, it will preserve relative insert order. This can affect the output of some special cases.

=====How to Run Code=====
Compile with: gcc find_route.c
Run with: ./a.out input_file Origin_City Destination_City heuristic_file
(example: ./a.out input1.txt Bremen Kassel h_kassel.txt)
	- you can omit the heuristic_file if you want to do an uninformed search


